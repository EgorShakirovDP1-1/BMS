import os
from file_sys import *




    

    
while(True):
    #Buildings = openTextFile("Buildings.txt", "r")
    user_choice = print_main_menu() # prints main menu

    os.system("cls")
    if (user_choice == 1): # View data
        while(True):
            indexOfFile = userChoosesFile()
            if(indexOfFile == 4):
                os.system("cls")
                break
            else:
                file = openTextFile("r", indexOfFile)
                os.system("cls")
                printTxtFile(file, indexOfFile)
                input("Press any button to continue: ")
                os.system("cls")
                break
            
    elif(user_choice == 2): # if user chose to sort
        indexOfFile = userChoosesFile()
        while(True):
            if(indexOfFile == 4):
                os.system("cls")
                break
            else:
                file = openTextFile("r", indexOfFile)
                os.system("cls")
                choice = chooseSortMethodScreen(file) # lets user choose between sorting options
                while type(choice) is None:
                    choice = chooseSortMethodScreen(file) # lets user choose between sorting options
                complete = False
                os.system("cls")
                while complete == False:
                    try:
                        if(choice >len(file[0])): # if user chose the go back option, this will return true
                            os.system("cls")
                            complete = True
                            break
                        else:
                            chooseUpOrDown(file, choice) # this will do many things
                            # this will allow the user to choose the order of their sorted data -ascending or descending
                            # after user has made their choice the sorted text file gets output in terminal and shown to user
                            input("Press any button to continue: ")
                            os.system("cls")
                            complete = True
                    except TypeError:
                        choice = chooseSortMethodScreen(file) 
                        continue
                break
                

    elif(user_choice == 3): # if user chose to filter
        indexOfFile = userChoosesFile()
        while(True):
            if(indexOfFile == 4):
                os.system("cls")
                break
            else:
                file = openTextFile("r", indexOfFile)
                os.system("cls")

                searchForUserInput(file, indexOfFile)
                input("Press any button to continue...")
                os.system("cls")
                break
    elif(user_choice == 4): # if user chose to view summary
        indexOfFile = userChoosesFile()
        while(True):
            if(indexOfFile == 4):
                os.system("cls")
                break
            else:
                file = openTextFile("r", indexOfFile)
                os.system("cls")
                summaryView(file,indexOfFile)
                input("Press any button to continue...")
                os.system("cls")
                break
    elif(user_choice == 5): # if user chose to edit data
        print("edit data")
        indexOfFile = userChoosesFile()
        file = openTextFile("r", indexOfFile)
        
        inputData(file, indexOfFile)
        
    elif(user_choice == 6): # if user chose to exit program
        
        break



input("Press any button to continue...")
